# Feminine Strength Co. Client Hub

This is the first reusable client-app build based on the Frankie prototype.

## Included
- Client view and Coach Hub
- Daily check-ins
- Training
- Nutrition
- Cycle tracking
- Movement/recovery
- Coach notes
- Progress
- Coach flags
- Exercise search library
- Mobile-first layout
- PWA manifest + service worker

## Important architecture note
The prototype still stores client activity locally in the browser. It is suitable for testing and demonstration, but it is not yet a multi-client cloud database.

## Next build
The next version should connect a real client data store so you can manage multiple clients centrally and use ChatGPT as the coaching/analysis layer.


## Supabase connection
This build is configured for the Supabase project supplied by the owner and syncs
Frankie's daily logs and coach notes to Supabase when the database tables exist.

Run `SUPABASE_SETUP.sql` in the Supabase SQL Editor before testing cloud sync.

Security note: the supplied key is a Supabase anon/public key. The database is
protected by RLS policies, but the current Frankie prototype policy is intentionally
a demo policy. Before real clients use the app, replace the fixed `client_key`
model with Supabase Auth and per-user RLS so one client cannot read another client's data.

- Built-in workout/rest timer with 30s, 45s, 60s, 90s, 2min and 10min presets

- Inline timer controls on workout exercises
- Client Attachments section prepared for Supabase Storage

- Timed mobility/recovery exercises: 30-second intervals and 5-minute box breathing

- Coached heavy lower-body day
- Per-exercise weight logging with Supabase sync
- YouTube demo search link for each exercise
